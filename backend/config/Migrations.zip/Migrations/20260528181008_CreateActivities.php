<?php
declare(strict_types=1);

use Migrations\BaseMigration;

class CreateActivities extends BaseMigration
{
    public function change(): void
    {
        $table = $this->table('activities', [
            'id' => false,
            'primary_key' => ['id'],
            'engine' => 'InnoDB',
            'collation' => 'utf8mb4_unicode_ci',
        ]);
        $table
            ->addColumn('id', 'biginteger', [
                'autoIncrement' => true,
                'null' => false,
                'signed' => false,
            ])
            ->addColumn('name', 'string', [
                'limit' => 255,
                'null' => false,
            ])
            ->addColumn('image', 'string', [
                'limit' => 255,
                'null' => false,
            ])
            ->addColumn('place', 'string', [
                'limit' => 255,
                'null' => false,
            ])
            ->addColumn('year', 'integer', [
                'null' => false,
            ])
            ->addColumn('start_date', 'datetime', [
                'null' => false,
            ])
            ->addColumn('duration_days', 'integer', [
                'null' => false,
            ])
            ->addColumn('total_vacancies', 'integer', [
                'null' => false,
            ])
            ->addColumn('category_id', 'biginteger', [
                'null' => false,
                'signed' => false,
            ])
            ->addColumn('activitable_type', 'string', [
                'limit' => 255,
                'null' => false,
            ])
            ->addColumn('activitable_id', 'biginteger', [
                'null' => false,
                'signed' => false,
            ])
            ->addColumn('created', 'datetime', [
                'null' => false,
            ])
            ->addColumn('modified', 'timestamp', [
                'null' => false,
            ])
            ->addColumn('deleted', 'datetime', [
                'null' => true,
                'default' => null,
            ])
            ->addIndex(['activitable_type', 'activitable_id'], [
                'name' => 'events_eventable_type_eventable_id_index',
            ])
            ->addForeignKey('category_id', 'categories', 'id', [
                'constraint' => 'activities_activity_categories_FK',
                'delete' => 'NO_ACTION',
                'update' => 'NO_ACTION',
            ])
            ->create();
    }
}
