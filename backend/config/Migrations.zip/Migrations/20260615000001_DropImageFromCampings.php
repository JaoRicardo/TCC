<?php
declare(strict_types=1);
use Migrations\BaseMigration;
class DropImageFromCampings extends BaseMigration {
    public function change(): void {
        $this->table('campings')->removeColumn('image')->update();
    }
}
